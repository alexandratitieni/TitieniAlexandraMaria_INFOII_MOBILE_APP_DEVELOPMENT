package com.example.simplecalcapp;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText et1, et2;
    private TextView tvRes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et1 = findViewById(R.id.editTextFirstNumber);
        et2 = findViewById(R.id.editTextSecondNumber);
        tvRes = findViewById(R.id.textViewResult);

        findViewById(R.id.btn_add).setOnClickListener(v -> calculate('+'));
        findViewById(R.id.btn_sub).setOnClickListener(v -> calculate('-'));
        findViewById(R.id.btn_mul).setOnClickListener(v -> calculate('*'));
        findViewById(R.id.btn_div).setOnClickListener(v -> calculate('/'));
    }

    private void calculate(char op) {
        String s1 = et1.getText().toString();
        String s2 = et2.getText().toString();

        if (s1.isEmpty() || s2.isEmpty()) {
            tvRes.setText("Error");
            return;
        }

        double n1 = Double.parseDouble(s1);
        double n2 = Double.parseDouble(s2);
        double res = 0;

        switch (op) {
            case '+': 
		    res = n1 + n2; 
		    break;

            case '-': 
		    res = n1 - n2; 
	 	    break;

            case '*': 
		    res = n1 * n2; 
		    break;

            case '/':
                if (n2 != 0) 
		    res = n1 / n2;
                else 
		    { 
		        tvRes.setText("Div/0"); 
		        return; 
		    }
                break;
        }
        tvRes.setText(String.valueOf(res));
    }
}